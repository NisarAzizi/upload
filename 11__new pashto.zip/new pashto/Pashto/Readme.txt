Readme Important:

Before to install this Pashto Support

1.	Click the Regional and Language Option in Control panel
2.	Choose Language Tab
3.	Mark the Install Files for Complex script and right-to-left Language
4.	Insert Windows XP CD in your CD-Rom Drive
5.	Click the NO butoon and Choose Advanced Tab in the Regional and Language Option
6.	Select Arabic (Saudi Arabia) in Scroll list (Select a Language to match the language version...)
7.	Restart your Computer and run this setup again.


The Afghansoft Team
E-mails:	hunarmal_maiwand@yahoo.com
		hunarmal_maiwand@hotmail.com
		hunarmalmaiwand@gmail.com

Webs:		www.worbal.com/computer
		hunarmal.blogfa.com

Mobiles:	0093-700306562
		0093-772428585